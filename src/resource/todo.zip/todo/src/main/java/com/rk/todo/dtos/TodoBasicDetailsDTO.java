package com.rk.todo.dtos;

import java.time.LocalDate;


public class TodoBasicDetailsDTO {
	
	private int id;
	private String description;
	private boolean done ;
	private LocalDate targetDate;
	
	
	public TodoBasicDetailsDTO ( int id, String description, boolean done )
	{
		this.id=id;
		this.description=description;
		this.done=done;
		this.targetDate=LocalDate.now();
	}


	public TodoBasicDetailsDTO() {
		// TODO Auto-generated constructor stub
	}


	public LocalDate getTargetDate() {
		return targetDate;
	}


	public void setTargetDate(LocalDate targetDate) {
		this.targetDate = targetDate;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public boolean isDone() {
		return done;
	}


	public void setDone(boolean done) {
		this.done = done;
	}
	
	
}
